This zip contains the x64 build of eyelink_core and a sample program for Mac OS X.  Both compiled as debug, so when things fail, I have a chance to get some info. The eyelink_core_graphics is not provided with this, as the dependent SDL frameworks are not available for Mac OSX x64 platform.

Note: the eyelink_core is still a BETA version, and is ONLY intended for testing purposes.
To run:
1. Please place the framework in ~/Library/Frameworks.
2. Run the command line program simpleexample using a terminal. 

Please send bug reports to suganthan@sr-research.com.